@extends('admin.common.app')
@section('main')
<style>
    .select-card {
    margin-right: 10px;
    cursor: pointer;
}

.card {
    cursor: pointer;
    border: 1px solid #ddd;
    transition: box-shadow 0.3s ease;
}

.card.selected {
    box-shadow: 0 0 10px rgba(0, 123, 255, 0.5);
}

.card-footer {
    display: none;
}

.card-footer.active {
    display: block;
}
.header-delete-btn {
    display: none;
    margin-bottom: 10px;
}

.header-delete-btn.active {
    display: block;
}


    </style>
<div class="pcoded-content">
    <!-- Page-header start -->
    <div class="page-header">
       
    </div>
    <div class="pcoded-inner-content">
        <!-- Main-body start -->
        <div class="main-body">
            <div class="page-wrapper">
                <!-- Page-body start -->
                <div class="page-body">
                    <!-- show success and error messages -->
                    @if (session('success'))
                            <div class="alert alert-success" role="alert">
                                {{ session('success') }}
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                            </div>
                            @endif
                            @if (session('error'))
                            <div class="alert alert-danger" role="alert">
                                {{ session('error') }}
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                            </div>
                            @endif
                            <!-- End show success and error messages -->
                            <h4>Assigned Leads</h4>
                            <div class="header-delete-btn">
                                <form id="delete-form" method="POST" action="{{ route('bluck_delete_assign') }}">
                                    @csrf
                                    <input type="hidden" name="selected_ids" id="selected-ids" value="">
                                    <button type="submit" class="btn btn-danger">Delete Selected</button>
                                </form>
                            </div>
                    <div class="row">
                        <!-- task, page, download counter  start -->
                        @if(!empty($datas))
                        @foreach($datas as $data)
                        @php
                            $data_id = json_decode($data->data_id);
                            $ids = explode(',', $data_id[0]);
                            $total = count($ids);
                            $users = App\Models\User::whereNull('deleted_at')
                                ->where('id', $data->agent_id)
                                ->first();
                        @endphp
                        <div class="col-xl-3 col-md-6">
                            <div class="card">
                                <div class="card-block" onclick="toggleFooter(this)">
                                    <div class="row align-items-center">
                                        <div class="col-8">
                                            <input type="checkbox" class="select-card" data-id="{{ $data->id }}">
                                            <h5 class="text-c-purple m-b-10"> {{$total}} Data To</h5>
                                            <h6 class="text-muted m-b-1">
                                                <span class="badge badge-dark" style="padding: 5px; font-size:12px; font-weight:50">
                                                    {{ $users->name }}
                                                </span>
                                            </h6>
                                            <h6 class="text-muted m-b-0">Date: {{$data->created_at}}</h6>
                                        </div>
                                        <div class="col-4 text-right">
                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" style="fill:green;">
                                                <path
                                                    d="M190.5 68.8L225.3 128H224 152c-22.1 0-40-17.9-40-40s17.9-40 40-40h2.2c14.9 0 28.8 7.9 36.3 20.8zM64 88c0 14.4 3.5 28 9.6 40H32c-17.7 0-32 14.3-32 32v64c0 17.7 14.3 32 32 32H480c17.7 0 32-14.3 32-32V160c0-17.7-14.3-32-32-32H438.4c6.1-12 9.6-25.6 9.6-40c0-48.6-39.4-88-88-88h-2.2c-31.9 0-61.5 16.9-77.7 44.4L256 85.5l-24.1-41C215.7 16.9 186.1 0 154.2 0H152C103.4 0 64 39.4 64 88zm336 0c0 22.1-17.9 40-40 40H288h-1.3l34.8-59.2C329.1 55.9 342.9 48 357.8 48H360c22.1 0 40 17.9 40 40zM32 288V464c0 26.5 21.5 48 48 48H224V288H32zM288 512H432c26.5 0 48-21.5 48-48V288H288V512z" />
                                            </svg>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-footer bg-c-purple" style="display:none;">
                                    <div class="row align-items-center">
                                        <div class="col-6">
                                            <button type="button" class="btn btn-success"
                                                onclick="window.location.href='{{ route('assigned_leads_view',['assign' => base64_encode($data->id)]) }}'">
                                                View Data
                                            </button>
                                        </div>
                                        <div class="col-6">
                                            <button class="btn btn-danger"
                                                onclick="window.location.href='{{ route('assigned_leads_delete', [base64_encode($data->id)]) }}'">
                                                <i class="ti-trash"></i> All
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        @endforeach
                    @endif
                    
                        <!-- task, page, download counter  end -->
                    </div>
                </div>
                <!-- Page-body end -->
            </div>

        </div>
    </div>
    <script>
    function toggleFooter(cardBlock) {
        var footer = cardBlock.nextElementSibling; // Get the next sibling element (footer)
        if (footer.style.display === "none") {
            footer.style.display = "block"; // Show the footer if it's hidden
        } else {
            footer.style.display = "none"; // Hide the footer if it's visible
        }
    }
    </script>
    <script>
        document.querySelectorAll('.select-card').forEach(function(checkbox) {
    checkbox.addEventListener('change', function() {
        const card = this.closest('.card');
        if (this.checked) {
            card.classList.add('selected');
            card.querySelector('.card-footer').classList.add('active');
        } else {
            card.classList.remove('selected');
            card.querySelector('.card-footer').classList.remove('active');
        }
    });
});

let selectedIds = [];

document.querySelectorAll('.select-card').forEach(function(checkbox) {
    checkbox.addEventListener('change', function() {
        const card = this.closest('.card');
        const id = this.getAttribute('data-id');

        if (this.checked) {
            card.classList.add('selected');
            card.querySelector('.card-footer').classList.add('active');
            selectedIds.push(id); // Add selected ID to array
        } else {
            card.classList.remove('selected');
            card.querySelector('.card-footer').classList.remove('active');
            selectedIds = selectedIds.filter(function(item) {
                return item !== id; // Remove unselected ID from array
            });
        }

        toggleDeleteButton(); // Call the function to toggle delete button
    });
});

function toggleDeleteButton() {
    const deleteBtn = document.querySelector('.header-delete-btn');
    if (selectedIds.length > 0) {
        deleteBtn.classList.add('active'); // Show delete button
        document.getElementById('selected-ids').value = selectedIds.join(','); // Update hidden input value with selected IDs
    } else {
        deleteBtn.classList.remove('active'); // Hide delete button if no IDs are selected
        document.getElementById('selected-ids').value = ''; // Clear hidden input if no IDs are selected
    }
}

        </script>

    @endsection