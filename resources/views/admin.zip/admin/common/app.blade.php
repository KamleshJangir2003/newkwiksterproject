@include('admin.common.header')
@include('admin.common.sidebar')
@yield('main')
@include('admin.common.footer')