@extends('admin.common.app')
@section('main')
    <style>
        background-repeat: no-repeat;
        position: absolute;
        left: 0;
        right: 0;
        top: 0;
        bottom: 0
        }

        .profile-header .profile-header-cover:before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(to bottom, rgba(0, 0, 0, 0) 0, rgba(0, 0, 0, .75) 100%)
        }

        .profile-header .profile-header-content {
            color: #fff;
            padding: 25px
        }

        .profile-header-img {
            float: left;
            width: 120px;
            height: 120px;
            overflow: hidden;
            position: relative;
            z-index: 10;
            margin: 0 0 -20px;
            padding: 3px;
            border-radius: 4px;
            background: #fff
        }

        .profile-header-img img {
            max-width: 100%
        }

        .profile-header-info h4 {
            font-weight: 500;
            color: #fff
        }

        .profile-header-img+.profile-header-info {
            margin-left: 140px
        }

        .profile-header .profile-header-content,
        .profile-header .profile-header-tab {
            position: relative
        }

        .b-minus-1,
        .b-minus-10,
        .b-minus-2,
        .b-minus-3,
        .b-minus-4,
        .b-minus-5,
        .b-minus-6,
        .b-minus-7,
        .b-minus-8,
        .b-minus-9,
        .b-plus-1,
        .b-plus-10,
        .b-plus-2,
        .b-plus-3,
        .b-plus-4,
        .b-plus-5,
        .b-plus-6,
        .b-plus-7,
        .b-plus-8,
        .b-plus-9,
        .l-minus-1,
        .l-minus-2,
        .l-minus-3,
        .l-minus-4,
        .l-minus-5,
        .l-minus-6,
        .l-minus-7,
        .l-minus-8,
        .l-minus-9,
        .l-plus-1,
        .l-plus-10,
        .l-plus-2,
        .l-plus-3,
        .l-plus-4,
        .l-plus-5,
        .l-plus-6,
        .l-plus-7,
        .l-plus-8,
        .l-plus-9,
        .r-minus-1,
        .r-minus-10,
        .r-minus-2,
        .r-minus-3,
        .r-minus-4,
        .r-minus-5,
        .r-minus-6,
        .r-minus-7,
        .r-minus-8,
        .r-minus-9,
        .r-plus-1,
        .r-plus-10,
        .r-plus-2,
        .r-plus-3,
        .r-plus-4,
        .r-plus-5,
        .r-plus-6,
        .r-plus-7,
        .r-plus-8,
        .r-plus-9,
        .t-minus-1,
        .t-minus-10,
        .t-minus-2,
        .t-minus-3,
        .t-minus-4,
        .t-minus-5,
        .t-minus-6,
        .t-minus-7,
        .t-minus-8,
        .t-minus-9,
        .t-plus-1,
        .t-plus-10,
        .t-plus-2,
        .t-plus-3,
        .t-plus-4,
        .t-plus-5,
        .t-plus-6,
        .t-plus-7,
        .t-plus-8,
        .t-plus-9 {
            position: relative !important
        }

        .profile-header .profile-header-tab {
            background: #fff;
            list-style-type: none;
            margin: -10px 0 0;
            padding: 0 0 0 140px;
            white-space: nowrap;
            border-radius: 0
        }

        .text-ellipsis,
        .text-nowrap {
            white-space: nowrap !important
        }

        .profile-header .profile-header-tab>li {
            display: inline-block;
            margin: 0
        }

        .profile-header .profile-header-tab>li>a {
            display: block;
            color: #929ba1;
            line-height: 20px;
            padding: 10px 20px;
            text-decoration: none;
            font-weight: 700;
            font-size: 12px;
            border: none
        }

        .profile-header .profile-header-tab>li.active>a,
        .profile-header .profile-header-tab>li>a.active {
            color: #242a30
        }

        .profile-content {
            padding: 25px;
            border-radius: 4px
        }

        .profile-content:after,
        .profile-content:before {
            content: '';
            display: table;
            clear: both
        }

        .profile-content .tab-content,
        .profile-content .tab-pane {
            background: 0 0
        }

        .profile-left {
            width: 200px;
            float: left
        }

        .profile-right {
            margin-left: 240px;
            padding-right: 20px
        }

        .profile-image {
            height: 175px;
            line-height: 175px;
            text-align: center;
            font-size: 72px;
            margin-bottom: 10px;
            border: 2px solid #E2E7EB;
            overflow: hidden;
            border-radius: 4px
        }

        .profile-image img {
            display: block;
            max-width: 100%
        }

        .profile-highlight {
            padding: 12px 15px;
            background: #FEFDE1;
            border-radius: 4px
        }

        .profile-highlight h4 {
            margin: 0 0 7px;
            font-size: 12px;
            font-weight: 700
        }

        .table.table-profile>thead>tr>th {
            border-bottom: none !important
        }

        .table.table-profile>thead>tr>th h4 {
            font-size: 20px;
            margin-top: 0
        }

        .table.table-profile>thead>tr>th h4 small {
            display: block;
            font-size: 12px;
            font-weight: 400;
            margin-top: 5px
        }

        .table.table-profile>tbody>tr>td,
        .table.table-profile>thead>tr>th {
            border: none;
            padding-top: 7px;
            padding-bottom: 7px;
            color: #242a30;
            background: 0 0
        }

        .table.table-profile>tbody>tr>td.field {
            width: 20%;
            text-align: right;
            font-weight: 600;
            color: #2d353c
        }

        .table.table-profile>tbody>tr.highlight>td {
            border-top: 1px solid #b9c3ca;
            border-bottom: 1px solid #b9c3ca
        }

        .table.table-profile>tbody>tr.divider>td {
            padding: 0 !important;
            height: 10px
        }

        .profile-section+.profile-section {
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid #b9c3ca
        }

        .profile-section:after,
        .profile-section:before {
            content: '';
            display: table;
            clear: both
        }

        .profile-section .title {
            font-size: 20px;
            margin: 0 0 15px
        }

        .profile-section .title small {
            font-weight: 400
        }

        body.flat-black {
            background: #E7E7E7
        }

        .flat-black .navbar.navbar-inverse {
            background: #212121
        }

        .flat-black .navbar.navbar-inverse .navbar-form .form-control {
            background: #4a4a4a;
            border-color: #4a4a4a
        }

        .flat-black .sidebar,
        .flat-black .sidebar-bg {
            background: #3A3A3A
        }

        .flat-black .page-with-light-sidebar .sidebar,
        .flat-black .page-with-light-sidebar .sidebar-bg {
            background: #fff
        }

        .flat-black .sidebar .nav>li>a {
            color: #b2b2b2
        }

        .flat-black .sidebar.sidebar-grid .nav>li>a {
            border-bottom: 1px solid #474747;
            border-top: 1px solid #474747
        }

        .flat-black .sidebar .active .sub-menu>li.active>a,
        .flat-black .sidebar .nav>li.active>a,
        .flat-black .sidebar .nav>li>a:focus,
        .flat-black .sidebar .nav>li>a:hover,
        .flat-black .sidebar .sub-menu>li>a:focus,
        .flat-black .sidebar .sub-menu>li>a:hover,
        .sidebar .nav>li.nav-profile>a {
            color: #fff
        }

        .flat-black .sidebar .sub-menu>li>a,
        .flat-black .sidebar .sub-menu>li>a:before {
            color: #999
        }

        .flat-black .page-with-light-sidebar .sidebar .active .sub-menu>li.active>a,
        .flat-black .page-with-light-sidebar .sidebar .active .sub-menu>li.active>a:focus,
        .flat-black .page-with-light-sidebar .sidebar .active .sub-menu>li.active>a:hover,
        .flat-black .page-with-light-sidebar .sidebar .nav>li.active>a,
        .flat-black .page-with-light-sidebar .sidebar .nav>li.active>a:focus,
        .flat-black .page-with-light-sidebar .sidebar .nav>li.active>a:hover {
            color: #000
        }

        .flat-black .page-sidebar-minified .sidebar .nav>li.has-sub:focus>a,
        .flat-black .page-sidebar-minified .sidebar .nav>li.has-sub:hover>a {
            background: #323232
        }

        .flat-black .page-sidebar-minified .sidebar .nav li.has-sub>.sub-menu,
        .flat-black .sidebar .nav>li.active>a,
        .flat-black .sidebar .nav>li.active>a:focus,
        .flat-black .sidebar .nav>li.active>a:hover,
        .flat-black .sidebar .nav>li.nav-profile,
        .flat-black .sidebar .sub-menu>li.has-sub>a:before,
        .flat-black .sidebar .sub-menu>li:before,
        .flat-black .sidebar .sub-menu>li>a:after {
            background: #2A2A2A
        }

        .flat-black .page-sidebar-minified .sidebar .sub-menu>li:before,
        .flat-black .page-sidebar-minified .sidebar .sub-menu>li>a:after {
            background: #3e3e3e
        }

        .flat-black .sidebar .nav>li.nav-profile .cover.with-shadow:before {
            background: rgba(42, 42, 42, .75)
        }

        .bg-white {
            background-color: #fff !important;
        }

        .p-10 {
            padding: 10px !important;
        }

        .media.media-xs .media-object {
            width: 32px;
        }

        .m-b-2 {
            margin-bottom: 2px !important;
        }

        .media>.media-left,
        .media>.pull-left {
            padding-right: 15px;
        }

        .media-body,
        .media-left,
        .media-right {
            display: table-cell;
            vertical-align: top;
        }

        select.form-control:not([size]):not([multiple]) {
            height: 34px;
        }

        .form-control.input-inline {
            display: inline;
            width: auto;
            padding: 0 7px;
        }
    </style>
    <style>
        .profile-content {
            display: none;
        }

        .profile-content.active {
            display: block;
        }

        .nav-item.active .nav-link {
            border-bottom: 2px solid blue;
            /* Change the color of the underline */
        }
    </style>
    <div class="pcoded-content">
        <!-- Page-header start -->
        <div class="page-header">
            {{-- <div class="page-block">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <div class="page-header-title">
                            <h5 class="m-b-10">Profile</h5>

                        </div>
                    </div>
                    <div class="col-md-4">
                        <ul class="breadcrumb-title">
                            <li class="breadcrumb-item">
                                <a href="index.html"> <i class="fa fa-home"></i> </a>
                            </li>
                            <li class="breadcrumb-item"><a href="#!">Dashboard</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div> --}}
        </div>
        <div class="pcoded-inner-content">
            <!-- Main-body start -->
            <div class="main-body">
                <div class="page-wrapper">
                    <!-- Page-body start -->
                    <div class="page-body">
                        <div class="row">

                            <div class="container">
                                <div class="main-body">
                                    <div class="row">

                                        <div class="container">
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <link
                                                        href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css"
                                                        rel="stylesheet">
                                                    <div class="container">
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <div id="content" class="content content-full-width">
                                                                    <!-- begin profile -->
                                                                    <div class="profile">
                                                                        <div class="profile-header">
                                                                            <!-- BEGIN profile-header-cover -->
                                                                            <div class="profile-header-cover"></div>
                                                                            <!-- END profile-header-cover -->
                                                                            <!-- BEGIN profile-header-content -->
                                                                            <div class="profile-header-content">
                                                                                <!-- BEGIN profile-header-img -->
                                                                                <div class="profile-header-img">
                                                                                    @if (!empty($profile_data->gender) && $profile_data->gender == 2)
                                                                                        <img src="https://bootdey.com/img/Content/avatar/avatar3.png"
                                                                                            alt="">
                                                                                    @else
                                                                                        <img src="https://bootdey.com/img/Content/avatar/avatar7.png"
                                                                                            alt="">
                                                                                    @endif
                                                                                </div>
                                                                                <!-- END profile-header-img -->
                                                                                <!-- BEGIN profile-header-info -->
                                                                                <div class="profile-header-info">
                                                                                    <h4 class="m-t-10 m-b-5"
                                                                                        style="color:black">
                                                                                        {{ $profile->name }}</h4>
                                                                                    <p class="m-b-10"style="color:black">
                                                                                        {{ session('position') }}</p>
                                                                                    @if ($profile->is_active == 1)
                                                                                        <a href="{{ route('UpdateTeamStatus', ['active', base64_encode($profile->id)]) }}"
                                                                                            class="btn btn-xs btn-success">Active</a>
                                                                                    @else
                                                                                        <a href="{{ route('UpdateTeamStatus', ['inactive', base64_encode($profile->id)]) }}"
                                                                                            class="btn btn-xs btn-danger">Inactive</a>
                                                                                    @endif
                                                                                </div>
                                                                                <!-- END profile-header-info -->
                                                                            </div>
                                                                            <!-- END profile-header-content -->
                                                                            <!-- BEGIN profile-header-tab -->
                                                                            <ul class="profile-header-tab nav nav-tabs">
                                                                                <li class="nav-item">
                                                                                    <a href="#"
                                                                                        class="nav-link active"
                                                                                        data-tab="#personal-details">Personal
                                                                                        details</a>
                                                                                </li>
                                                                                <li class="nav-item">
                                                                                    <a href="#" class="nav-link"
                                                                                        data-tab="#current-employment">Current
                                                                                        employment</a>
                                                                                </li>
                                                                                <li class="nav-item">
                                                                                    <a href="#" class="nav-link"
                                                                                        data-tab="#identity_proofs">identity_proofs</a>
                                                                                </li>
                                                                                <li class="nav-item">
                                                                                    <a href="#" class="nav-link"
                                                                                        data-tab="#salary_details">Salary
                                                                                        Details</a>
                                                                                </li>
                                                                            </ul>
                                                                            <!-- END profile-header-tab -->
                                                                        </div>
                                                                    </div>
                                                                    <!-- end profile -->
                                                                    <!-- begin profile-content -->
                                                                    <div class="profile-content active"
                                                                        id="personal-details">
                                                                        <!-- begin tab-content -->
                                                                        <div class="tab-content p-0">

                                                                            <!-- begin #profile-about tab -->
                                                                            <div class="tab-pane fade in active show">
                                                                                <!-- begin table -->
                                                                                <div class="table-responsive">
                                                                                    <form
                                                                                        action="{{ route('update_team_process') }}"
                                                                                        method="post"
                                                                                        enctype="multipart/form-data">
                                                                                        @csrf
                                                                                        <div class="form-group row">
                                                                                            <div class="col-sm-4">
                                                                                                <div class="form-floating">
                                                                                                    <label>Name</label>
                                                                                                    <input type="text"
                                                                                                        class="form-control"
                                                                                                        type="text"
                                                                                                        value="{{ $profile_data->name ?? '' }}"
                                                                                                        id="name"
                                                                                                        name="name"
                                                                                                        placeholder="Enter name"
                                                                                                        required>

                                                                                                </div>
                                                                                                @error('name')
                                                                                                    <div style="color:red">
                                                                                                        {{ $message }}
                                                                                                    </div>
                                                                                                @enderror
                                                                                            </div>
                                                                                            <div class="col-sm-4">
                                                                                                <div class="form-floating">
                                                                                                    <label>Alis name</label>
                                                                                                    <input
                                                                                                        class="form-control"
                                                                                                        type="text"
                                                                                                        value="{{ $profile_data->alise_name ?? '' }}"
                                                                                                        id="alise_name"
                                                                                                        name="alise_name"
                                                                                                        placeholder="Enter Alis name"
                                                                                                        required>

                                                                                                </div>
                                                                                                @error('alise_name')
                                                                                                    <div style="color:red">
                                                                                                        {{ $message }}
                                                                                                    </div>
                                                                                                @enderror
                                                                                            </div>
                                                                                            <div class="col-sm-4">
                                                                                                <div class="form-floating">
                                                                                                    <label>Phone</label>
                                                                                                    <input
                                                                                                        class="form-control"
                                                                                                        type="text"
                                                                                                        value="{{ $profile_data->phone ?? '' }}"
                                                                                                        id="phone"
                                                                                                        name="phone"
                                                                                                        placeholder="phone no. "
                                                                                                        onkeypress="return isNumberKey(event)"
                                                                                                        maxlength="10"
                                                                                                        minlength="10">

                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="form-group row">
                                                                                            <div class="col-sm-4 mt-2">
                                                                                                <label>Blood Group</label>
                                                                                                <select
                                                                                                    class="form-control"
                                                                                                    name="blood"
                                                                                                    id="blood"
                                                                                                    required>
                                                                                                    <option value="1">
                                                                                                        Please select Blood
                                                                                                        group

                                                                                                    </option>
                                                                                                    <option
                                                                                                        value="A+"{{ $profile_data && $profile_data->blood == 'A+' ? 'selected' : '' }}>
                                                                                                        A+</option>
                                                                                                    <option
                                                                                                        value="A-"{{ $profile_data && $profile_data->blood == 'A-' ? 'selected' : '' }}>
                                                                                                        A-</option>
                                                                                                    <option
                                                                                                        value="B+"{{ $profile_data && $profile_data->blood == 'B+' ? 'selected' : '' }}>
                                                                                                        B+</option>
                                                                                                    <option
                                                                                                        value="B-"{{ $profile_data && $profile_data->blood == 'B-' ? 'selected' : '' }}>
                                                                                                        B-</option>
                                                                                                    <option
                                                                                                        value="AB+"{{ $profile_data && $profile_data->blood == 'AB+' ? 'selected' : '' }}>
                                                                                                        AB+</option>
                                                                                                    <option
                                                                                                        value="AB-"{{ $profile_data && $profile_data->blood == 'AB-' ? 'selected' : '' }}>
                                                                                                        AB-</option>
                                                                                                    <option
                                                                                                        value="O+"{{ $profile_data && $profile_data->blood == 'O+' ? 'selected' : '' }}>
                                                                                                        O+</option>
                                                                                                    <option
                                                                                                        value="O-"{{ $profile_data && $profile_data->blood == 'O-' ? 'selected' : '' }}>
                                                                                                        O-</option>

                                                                                                </select>
                                                                                                <div class="form-floating">
                                                                                                    @error('blood')
                                                                                                        <div style="color:red">
                                                                                                            {{ $message }}
                                                                                                        </div>
                                                                                                    @enderror
                                                                                                </div>
                                                                                            </div>
                                                                                            <div class="col-sm-4 mt-2">
                                                                                                <label>Gender</label>
                                                                                                <select
                                                                                                    class="form-control"
                                                                                                    name="gender"
                                                                                                    id="gender"
                                                                                                    required>
                                                                                                    <option value="1">
                                                                                                        Please select Gender
                                                                                                    </option>
                                                                                                    <option
                                                                                                        value="1"{{ $profile_data && $profile_data->gender == 1 ? 'selected' : '' }}>
                                                                                                        Male</option>
                                                                                                    <option
                                                                                                        value="2"{{ $profile_data && $profile_data->gender == 2 ? 'selected' : '' }}>
                                                                                                        female</option>

                                                                                                </select>
                                                                                                <div class="form-floating">
                                                                                                    @error('power')
                                                                                                        <div style="color:red">
                                                                                                            {{ $message }}
                                                                                                        </div>
                                                                                                    @enderror
                                                                                                </div>
                                                                                            </div>
                                                                                            <div class="col-sm-4 mt-2">
                                                                                                <label>Marital
                                                                                                    Status</label>
                                                                                                <select
                                                                                                    class="form-control"
                                                                                                    name="marital"
                                                                                                    id="marital"
                                                                                                    required>
                                                                                                    <option value="">
                                                                                                        Please select
                                                                                                        Marital Status

                                                                                                    </option>
                                                                                                    <option
                                                                                                        value="1"{{ $profile_data && $profile_data->marital == 1 ? 'selected' : '' }}>
                                                                                                        Married</option>
                                                                                                    <option
                                                                                                        value="2"{{ $profile_data && $profile_data->marital == 2 ? 'selected' : '' }}>
                                                                                                        Unmarried</option>

                                                                                                </select>
                                                                                                <div class="form-floating">
                                                                                                    @error('power')
                                                                                                        <div style="color:red">
                                                                                                            {{ $message }}
                                                                                                        </div>
                                                                                                    @enderror
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="form-group row">
                                                                                            <div class="col-sm-4">
                                                                                                <label>Date of birth</label>
                                                                                                <div class="form-floating">
                                                                                                    <input type="date"
                                                                                                        class="form-control"
                                                                                                        type="date"
                                                                                                        value="{{ $profile_data->dob ?? '' }}"
                                                                                                        id="dob"
                                                                                                        name="dob"
                                                                                                        placeholder="dob"
                                                                                                        required>
                                                                                                </div>
                                                                                                @error('dob')
                                                                                                    <div style="color:red">
                                                                                                        {{ $message }}
                                                                                                    </div>
                                                                                                @enderror
                                                                                            </div>
                                                                                            <div class="col-sm-4">
                                                                                                <div class="form-floating">
                                                                                                    <label>Guardian's
                                                                                                        Name</label>
                                                                                                    <input
                                                                                                        class="form-control"
                                                                                                        type="text"
                                                                                                        value="{{ $profile_data->guardian_name ?? '' }}"
                                                                                                        id="guardian_name"
                                                                                                        name="guardian_name"
                                                                                                        placeholder="Guardian's Name"
                                                                                                        required>

                                                                                                </div>
                                                                                                @error('guardian_name')
                                                                                                    <div style="color:red">
                                                                                                        {{ $message }}
                                                                                                    </div>
                                                                                                @enderror
                                                                                            </div>
                                                                                            <div class="col-sm-4">
                                                                                                <div class="form-floating">
                                                                                                    <label>Emergency Contact
                                                                                                        Name</label>
                                                                                                    <input
                                                                                                        class="form-control"
                                                                                                        type="text"
                                                                                                        value="{{ $profile_data->em_name ?? '' }}"
                                                                                                        id="em_name"
                                                                                                        name="em_name"
                                                                                                        placeholder="Emergency Contact Name">

                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="form-group row">
                                                                                            <div class="col-sm-4">
                                                                                                <div class="form-floating">
                                                                                                    <label>Emergency Contact
                                                                                                        Mobile</label>
                                                                                                    <input type="phone"
                                                                                                        class="form-control"
                                                                                                        type="phone"
                                                                                                        value="{{ $profile_data->em_number ?? '' }}"
                                                                                                        id="em_number"
                                                                                                        name="em_number"
                                                                                                        placeholder="Emergency Contact Mobile Number"
                                                                                                        required>
                                                                                                </div>
                                                                                                @error('name')
                                                                                                    <div style="color:red">
                                                                                                        {{ $message }}
                                                                                                    </div>
                                                                                                @enderror
                                                                                            </div>
                                                                                            <div class="col-sm-4">
                                                                                                <div class="form-floating">
                                                                                                    <label>Emergency Contact
                                                                                                        Relationship</label>
                                                                                                    <input
                                                                                                        class="form-control"
                                                                                                        type="text"
                                                                                                        value="{{ $profile_data->em_relation ?? '' }}"
                                                                                                        id="em_relation"
                                                                                                        name="em_relation"
                                                                                                        placeholder="Emergency Contact Relationship"
                                                                                                        required>

                                                                                                </div>
                                                                                                @error('em_relation')
                                                                                                    <div style="color:red">
                                                                                                        {{ $message }}
                                                                                                    </div>
                                                                                                @enderror
                                                                                            </div>
                                                                                            <div class="col-sm-4">
                                                                                                <div class="form-floating">
                                                                                                    <label>Emergency Contact
                                                                                                        Address</label>
                                                                                                    <input
                                                                                                        class="form-control"
                                                                                                        type="text"
                                                                                                        value="{{ $profile_data->em_address ?? '' }}"
                                                                                                        id="em_address"
                                                                                                        name="em_address"
                                                                                                        placeholder="Emergency Contact Address">

                                                                                                </div>
                                                                                            </div>
                                                                                        </div>

                                                                                        <input type="hidden"
                                                                                            name="id"
                                                                                            value="{{ $id }}">
                                                                                        <div class="form-group"
                                                                                            style="margin-left:50px">
                                                                                            <div class="w-100 text-center">
                                                                                                <button type="submit"
                                                                                                    class="btn btn-primary width-150">Update</button>
                                                                                                <button type="button"
                                                                                                    class="btn btn-white btn-white-without-border width-150 m-l-5"onclick="window.location.href='{{ route('view_team') }}'">Cancel</button>
                                                                                            </div>
                                                                                        </div>


                                                                                    </form>
                                                                                </div>
                                                                                <!-- end table -->
                                                                            </div>
                                                                            <!-- end #profile-about tab -->


                                                                        </div>
                                                                        <!-- end tab-content -->
                                                                    </div>
                                                                    <!-- end profile-content -->
                                                                    <div class="profile-content" id="current-employment">
                                                                        <!-- begin tab-content -->
                                                                        <div class="tab-content p-0">

                                                                            <!-- begin #profile-about tab -->
                                                                            <div class="tab-pane fade in active show" id>
                                                                                <!-- begin table -->
                                                                                <div class="table-responsive">
                                                                                    <form
                                                                                        action="{{ route('update_current_process') }}"
                                                                                        method="post"
                                                                                        enctype="multipart/form-data">
                                                                                        @csrf
                                                                                        <div class="form-group row">
                                                                                            <div class="col-sm-4">
                                                                                                <div class="form-floating">
                                                                                                    <label>Employ Id</label>
                                                                                                    <input type="text"
                                                                                                        class="form-control"
                                                                                                        type="text"
                                                                                                        value="{{ $current->employ_id ?? '' }}"
                                                                                                        id="name"
                                                                                                        name="employ_id"
                                                                                                        placeholder="Enter Employ Id"
                                                                                                        required>

                                                                                                </div>

                                                                                            </div>
                                                                                            <div class="col-sm-4">
                                                                                                <div class="form-floating">
                                                                                                    <label>Job Title</label>
                                                                                                    <input
                                                                                                        class="form-control"
                                                                                                        type="text"
                                                                                                        value="{{ $current->job_title ?? '' }}"
                                                                                                        id="job_title"
                                                                                                        name="job_title"
                                                                                                        placeholder="Enter Job Title"
                                                                                                        required>

                                                                                                </div>

                                                                                            </div>
                                                                                            <div class="col-sm-4">
                                                                                                <div class="form-floating">
                                                                                                    <label>Date of joining</label>
                                                                                                    <input
                                                                                                        class="form-control"
                                                                                                        type="date"
                                                                                                        value="{{ $current->doj ?? '' }}"
                                                                                                        id="phone"
                                                                                                        name="doj"
                                                                                                        placeholder="phone no. "
                                                                                                        >
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>

                                                                                        <input type="hidden"
                                                                                            name="id"
                                                                                            value="{{ $id }}">
                                                                                        <div class="form-group"
                                                                                            style="margin-left:50px">
                                                                                            <div class="w-100 text-center">
                                                                                                <button type="submit"
                                                                                                    class="btn btn-primary width-150">Update</button>
                                                                                                <button type="button"
                                                                                                    class="btn btn-white btn-white-without-border width-150 m-l-5"onclick="window.location.href='{{ route('view_team') }}'">Cancel</button>
                                                                                            </div>
                                                                                        </div>


                                                                                    </form>
                                                                                </div>
                                                                                <!-- end table -->
                                                                            </div>
                                                                            <!-- end #profile-about tab -->


                                                                        </div>
                                                                        <!-- end tab-content -->
                                                                    </div>


                                                                    <div class="profile-content" id="identity_proofs">
                                                                        <!-- begin tab-content -->
                                                                        <div class="tab-content p-0">

                                                                            <!-- begin #profile-about tab -->
                                                                            <div class="tab-pane fade in active show" id>
                                                                                <!-- begin table -->
                                                                                <div class="table-responsive">
                                                                                    <form
                                                                                        action="{{ route('update_identety_process') }}"
                                                                                        method="post"
                                                                                        enctype="multipart/form-data">
                                                                                        @csrf
                                                                                        <div class="form-group row">
                                                                                            <div class="col-sm-4">
                                                                                                <div class="form-floating">
                                                                                                    <label>Aadhar card</label>
                                                                                                    <input type="file"
                                                                                                        class="form-control"
                                                                                                        type="file"

                                                                                                        id="name"
                                                                                                        name="aadhar"
                                                                                                        placeholder="Enter Employ Id"
                                                                                                        >

                                                                                                </div>
                                                                                               @if(!empty($identety->aadhar_card))
                                                                                               <a href="{{url($identety->aadhar_card)}}" target="_blank">
                                                                                                <img src="{{url($identety->aadhar_card)}}" width="50px" height="50px" alt="Aadhar Card Image">
                                                                                            </a>
                                                                                               @else
                                                                                               <p>no image</p>
                                                                                               @endif
                                                                                            </div>
                                                                                            <div class="col-sm-4">
                                                                                                <div class="form-floating">
                                                                                                    <label>pan_card</label>
                                                                                                    <input
                                                                                                        class="form-control"
                                                                                                        type="file"

                                                                                                        id="alise_name"
                                                                                                        name="pan"
                                                                                                        placeholder="Enter Job Title"
                                                                                                        >

                                                                                                </div>
                                                                                                @if(!empty($identety->pan_card))
                                                                                                <a href="{{url($identety->pan_card)}}" target="_blank">
                                                                                                 <img src="{{url($identety->pan_card)}}" width="50px" height="50px" alt="pan Card Image">
                                                                                             </a>
                                                                                                @else
                                                                                                <p>no image</p>
                                                                                                @endif
                                                                                            </div>
                                                                                            <div class="col-sm-4">
                                                                                                <div class="form-floating">
                                                                                                    <label>Driving Licence</label>
                                                                                                    <input
                                                                                                        class="form-control"
                                                                                                        type="file"

                                                                                                        id="phone"
                                                                                                        name="licence"
                                                                                                        placeholder="phone no. "
                                                                                                        >
                                                                                                </div>
                                                                                                @if(!empty($identety->driving_licence))
                                                                                                <a href="{{url($identety->driving_licence)}}" target="_blank">
                                                                                                 <img src="{{url($identety->driving_licence)}}" width="50px" height="50px" alt="driving Card Image">
                                                                                             </a>
                                                                                                @else
                                                                                                <p>no image</p>
                                                                                                @endif
                                                                                            </div>
                                                                                        </div>

                                                                                        <input type="hidden"
                                                                                            name="id"
                                                                                            value="{{ $id }}">
                                                                                        <div class="form-group"
                                                                                            style="margin-left:50px">
                                                                                            <div class="w-100 text-center">
                                                                                                <button type="submit"
                                                                                                    class="btn btn-primary width-150">Update</button>
                                                                                                <button type="button"
                                                                                                    class="btn btn-white btn-white-without-border width-150 m-l-5"onclick="window.location.href='{{ route('view_team') }}'">Cancel</button>
                                                                                            </div>
                                                                                        </div>


                                                                                    </form>
                                                                                </div>
                                                                                <!-- end table -->
                                                                            </div>
                                                                            <!-- end #profile-about tab -->


                                                                        </div>
                                                                        <!-- end tab-content -->
                                                                    </div>

                                                                    <div class="profile-content" id="salary_details">
                                                                        <!-- begin tab-content -->
                                                                        <div class="tab-content p-0">

                                                                            <!-- begin #profile-about tab -->
                                                                            <div class="tab-pane fade in active show" id>
                                                                                <!-- begin table -->
                                                                                <div class="table-responsive">
                                                                                    <form
                                                                                        action="{{ route('update_salary_process') }}"
                                                                                        method="post"
                                                                                        enctype="multipart/form-data">
                                                                                        @csrf
                                                                                        <div class="form-group row">
                                                                                            <div class="col-sm-4">
                                                                                                <div class="form-floating">
                                                                                                    <label>Wage Type</label>
                                                                                                    <input type="text"
                                                                                                        class="form-control"
                                                                                                        type="text"
                                                                                                        value="{{ $salary->type ?? '' }}"
                                                                                                        id="name"
                                                                                                        name="type"
                                                                                                        placeholder="Monthly"
                                                                                                        required>

                                                                                                </div>

                                                                                            </div>
                                                                                            <div class="col-sm-4">
                                                                                                <div class="form-floating">
                                                                                                    <label>Salary Amount</label>
                                                                                                    <input
                                                                                                        class="form-control"
                                                                                                        type="text"
                                                                                                        value="{{ $salary->amount ?? '' }}"
                                                                                                        id="alise_name"
                                                                                                        name="amount"
                                                                                                        placeholder="Enter Amount"
                                                                                                        required>

                                                                                                </div>

                                                                                            </div>

                                                                                        </div>

                                                                                        <input type="hidden"
                                                                                            name="id"
                                                                                            value="{{ $id }}">
                                                                                        <div class="form-group"
                                                                                            style="margin-left:50px">
                                                                                            <div class="w-100 text-center">
                                                                                                <button type="submit"
                                                                                                    class="btn btn-primary width-150">Update</button>
                                                                                                <button type="button"
                                                                                                    class="btn btn-white btn-white-without-border width-150 m-l-5"onclick="window.location.href='{{ route('view_team') }}'">Cancel</button>
                                                                                            </div>
                                                                                        </div>


                                                                                    </form>
                                                                                </div>
                                                                                <!-- end table -->
                                                                            </div>
                                                                            <!-- end #profile-about tab -->


                                                                        </div>
                                                                        <!-- end tab-content -->
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Page-body end -->
                </div>
                <div id="styleSelector"> </div>
            </div>
        </div>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script>
            document.addEventListener("DOMContentLoaded", function() {
                // Get all tab links
                var tabLinks = document.querySelectorAll('.nav-link');

                // Add click event listener to each tab link
                tabLinks.forEach(function(link) {
                    link.addEventListener('click', function(e) {
                        e.preventDefault(); // Prevent default link behavior

                        // Get the target tab ID from data attribute
                        var tabId = this.getAttribute('data-tab');

                        // Remove 'active' class from all content elements
                        document.querySelectorAll('.profile-content').forEach(function(content) {
                            content.classList.remove('active');
                        });

                        // Remove 'active' class from all tab items
                        document.querySelectorAll('.nav-item').forEach(function(item) {
                            item.classList.remove('active');
                        });

                        // Add 'active' class to the target content element
                        document.querySelector(tabId).classList.add('active');

                        // Add 'active' class to the parent tab item
                        this.parentElement.classList.add('active');
                    });
                });
            });
        </script>
    @endsection
